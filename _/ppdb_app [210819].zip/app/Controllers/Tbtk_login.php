<?php

namespace App\Controllers;

use App\Models\TbtkModel;

class Tbtk_login extends BaseController
{
	protected $tbtkModel;

    public function __construct()
    {
        $this->tbtkModel = new TbtkModel();
    }

	public function index()
	{
		$data = [
			'title' => 'Login Calon Peserta Didik | PPDB Kampus Santa Ursula 2022-2023',
			'slug' => 'tbtk_login',
			'judul1' => 'PPDB ONLINE 2022-2023 <br><br> LOGIN CALON PESERTA DIDIK TB-TK SANTA URSULA',
			'judul2' => 'PPDB ONLINE 2022-2023 <br> TB-TK SANTA URSULA',
			'deskripsi' => 'Silahkan login menggunakan username dan password yang didapatkan saat melakukan pendaftaran',
			'bg_color' => 'color1'
		];
		return view('login/index', $data);
	}

	public function login()
	{
        $email = $this->request->getVar('email');
        $password = $this->request->getVar('password');

        $dataUser = $this->tbtkModel->where([
            'email' => $email,
            'deleted_at' => null,
        ])->first();

        if ($dataUser) {
			$pass = $dataUser->password;
            if (password_verify($password, $pass)) {
                session()->set([
                    'email' => $dataUser->email,
                    'nama_lengkap' => $dataUser->nama_lengkap,
                    'kota_lahir' => $dataUser->kota_lahir,
                    'tanggal_lahir' => $dataUser->tanggal_lahir,
                    'asal_sekolah' => $dataUser->asal_sekolah,
                    'pilihan_tingkat' => $dataUser->pilihan_tingkat,
                    'nama_orangtua' => $dataUser->nama_orangtua,
                    'email' => $dataUser->email,
                    'no_whatsapp' => $dataUser->no_whatsapp,
                    'bukti_pembayaran' => $dataUser->bukti_pembayaran,
                    'no_registrasi' => $dataUser->no_registrasi,
                    'no_virtual' => $dataUser->no_virtual,
                    'status_pendaftaran' => $dataUser->status_pendaftaran,
                    'status_penerimaan' => $dataUser->status_penerimaan,
                    'status_dapodik' => $dataUser->status_dapodik,
                    'status_keuangan' => $dataUser->status_keuangan,
                    'status_seragam' => $dataUser->status_seragam,
                    'status_buku' => $dataUser->status_buku,
                    'judul' => 'TB TK SANTA URSULA',
                    'nama_unit' => 'TB TK Santa Ursula',
                    'slug_unit' => 'tbtk',
                    'proses' => 'Observasi',
                    'unit' => 'tbtk_login',
                    'logged_in' => TRUE
                ]);
                return redirect()->to(base_url('/dashboard'));
            } else {
                session()->setFlashdata('error', 'Username & Password Salah');
                return redirect()->back();
            }
        } else {
            session()->setFlashdata('error', 'Username & Password Salah');
            return redirect()->back();
        }
	}

    public function logout()
	{
        session()->destroy();
        return redirect()->to('/home');
	}
}