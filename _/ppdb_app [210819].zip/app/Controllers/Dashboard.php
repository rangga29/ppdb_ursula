<?php

namespace App\Controllers;

class Dashboard extends BaseController
{
	public function index()
	{
		$data = [
			'title' => 'Dashboard Calon Peserta Didik | PPDB Kampus Santa Ursula 2022-2023',
		];
		return view('dashboard/index', $data);
	}

	public function data_calon_siswa()
	{
		$data = [
			'title' => 'Data Calon Siswa | PPDB Kampus Santa Ursula 2022-2023',
		];
		return view('dashboard/data_calon_siswa', $data);
	}
}