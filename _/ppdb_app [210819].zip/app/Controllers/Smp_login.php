<?php

namespace App\Controllers;

use App\Models\SmpModel;

class Smp_login extends BaseController
{
	protected $smpModel;

    public function __construct()
    {
        $this->smpModel = new SmpModel();
    }

    public function index()
	{
		$data = [
			'title' => 'Login Calon Peserta Didik | PPDB Kampus Santa Ursula 2022-2023',
			'slug' => 'smp_login',
			'judul1' => 'PPDB ONLINE 2022-2023 <br><br> LOGIN CALON PESERTA DIDIK SMP SANTA URSULA',
			'judul2' => 'PPDB ONLINE 2022-2023 <br> SMP SANTA URSULA',
			'deskripsi' => 'Silahkan login menggunakan username dan password yang didapatkan saat melakukan pendaftaran',
			'bg_color' => 'color3'
		];
		return view('login/index', $data);
	}

    public function login()
	{
        $email = $this->request->getVar('email');
        $password = $this->request->getVar('password');

        $dataUser = $this->smpModel->where([
            'email' => $email,
            'deleted_at' => null,
        ])->first();

        if ($dataUser) {
			$pass = $dataUser->password;
            if (password_verify($password, $pass)) {
                session()->set([
                    'email' => $dataUser->email,
                    'nama_lengkap' => $dataUser->nama_lengkap,
                    'kota_lahir' => $dataUser->kota_lahir,
                    'tanggal_lahir' => $dataUser->tanggal_lahir,
                    'asal_sekolah' => $dataUser->asal_sekolah,
                    'pilihan_tingkat' => $dataUser->pilihan_tingkat,
                    'nama_orangtua' => $dataUser->nama_orangtua,
                    'email' => $dataUser->email,
                    'no_whatsapp' => $dataUser->no_whatsapp,
                    'bukti_pembayaran' => $dataUser->bukti_pembayaran,
                    'surat_pengantar' => $dataUser->surat_pengantar,
                    'no_registrasi' => $dataUser->no_registrasi,
                    'no_virtual' => $dataUser->no_virtual,
                    'kelas4_sem1_indo' => $dataUser->kelas4_sem1_indo,
                    'kelas4_sem1_mat' => $dataUser->kelas4_sem1_mat,
                    'kelas4_sem2_indo' => $dataUser->kelas4_sem2_indo,
                    'kelas4_sem2_mat' => $dataUser->kelas4_sem2_mat,
                    'kelas5_sem1_indo' => $dataUser->kelas5_sem1_indo,
                    'kelas5_sem1_mat' => $dataUser->kelas5_sem1_mat,
                    'kelas5_sem2_indo' => $dataUser->kelas5_sem2_indo,
                    'kelas5_sem2_mat' => $dataUser->kelas5_sem2_mat,
                    'status_pendaftaran' => $dataUser->status_pendaftaran,
                    'status_penerimaan' => $dataUser->status_penerimaan,
                    'status_dapodik' => $dataUser->status_dapodik,
                    'status_keuangan' => $dataUser->status_keuangan,
                    'status_seragam' => $dataUser->status_seragam,
                    'status_buku' => $dataUser->status_buku,
                    'judul' => 'SMP SANTA URSULA',
                    'nama_unit' => 'SMP Santa Ursula',
                    'slug_unit' => 'smp',
                    'proses' => 'Tes Tertulis',
                    'unit' => 'smp_login',
                    'logged_in' => TRUE
                ]);
                return redirect()->to(base_url('/dashboard'));
            } else {
                session()->setFlashdata('error', 'Username & Password Salah');
                return redirect()->back();
            }
        } else {
            session()->setFlashdata('error', 'Username & Password Salah');
            return redirect()->back();
        }
	}

    public function logout()
	{
        session()->destroy();
        return redirect()->to('/home');
	}
}