<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title><?= $title ?></title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <link rel="shortcut icon" href="<?= base_url() ?>/back/images/favicon.ico">

    <link href="<?= base_url() ?>/back/plugins/dropify/css/dropify.min.css" rel="stylesheet">
    <link href="<?= base_url() ?>/back/plugins/filter/magnific-popup.css" rel="stylesheet" type="text/css" />

    <link href="<?= base_url() ?>/back/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
    <link href="<?= base_url() ?>/back/css/icons.min.css" rel="stylesheet" type="text/css" />
    <link href="<?= base_url() ?>/back/css/metisMenu.min.css" rel="stylesheet" type="text/css" />
    <link href="<?= base_url() ?>/back/css/style.css" rel="stylesheet" type="text/css" />

</head>

<body>
    <?= $this->include('dashboard/layouts/topbar') ?>

    <div class="page-wrapper">
        <div class="page-content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-sm-12">
                        <div class="page-title-box">
                            <h4 class="page-title">SELAMAT DATANG <b><?= session()->get('nama_lengkap') ?></b></h4>
                        </div>
                        <?= $this->renderSection('content') ?>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script src="<?= base_url() ?>/back/js/jquery.min.js"></script>
    <script src="<?= base_url() ?>/back/js/bootstrap.bundle.min.js"></script>
    <script src="<?= base_url() ?>/back/js/metisMenu.min.js"></script>
    <script src="<?= base_url() ?>/back/js/waves.min.js"></script>
    <script src="<?= base_url() ?>/back/js/jquery.slimscroll.min.js"></script>
    <script src="<?= base_url() ?>/back/plugins/dropify/js/dropify.min.js"></script>
    <script src="<?= base_url() ?>/back/pages/jquery.profile.init.js"></script>
    <script src="<?= base_url() ?>/back/plugins/filter/isotope.pkgd.min.js"></script>
    <script src="<?= base_url() ?>/back/plugins/filter/masonry.pkgd.min.js"></script>
    <script src="<?= base_url() ?>/back/plugins/filter/jquery.magnific-popup.min.js"></script>
    <script src="<?= base_url() ?>/back/pages/jquery.gallery.inity.js"></script>

    <script src="<?= base_url() ?>/back/js/app.js"></script>

</body>

</html>