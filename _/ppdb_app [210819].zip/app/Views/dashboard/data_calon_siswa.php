<?= $this->extend('dashboard/layouts/template') ?>

<?= $this->section('content') ?>
<?php
    if (session()->get('slug_unit') === 'tbtk') {
        $tingkat = 'tingkat';
        if (session()->get('pilihan_tingkat') === '1') {
            $tingkat = 'TB';
        } elseif (session()->get('pilihan_tingkat') === '2') {
            $tingkat = 'TK A';
        } else {
            $tingkat = 'TK B';
        }
    }
    else {
        $tingkat = 'Kelas ' . session()->get('pilihan_tingkat');
    }
?>
<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body  met-pro-bg">
                <div class="met-profile">
                    <div class="row">
                        <div class="col-lg-8 align-self-center mb-3 mb-lg-0">
                            <div class="met-profile-main">
                                <div class="met-profile-main-pic">
                                    <img src="<?= base_url() ?>/back/images/logo_serviam.png" alt=""
                                        style="max-width: 120px;" class="rounded-circle">
                                </div>
                                <div class="met-profile_user-detail">
                                    <h5 class="met-user-name"><?= session()->get('nama_lengkap') ?></h5>
                                    <p class="mb-0 met-user-name-post">
                                        <b>Calon Peserta Didik <?= $tingkat ?></b> - <?= session()->get('nama_unit') ?>
                                    </p>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-4 ml-auto">
                            <ul class="list-unstyled personal-detail">
                                <li class=""><i class="dripicons-document-new mr-2 text-info font-18"></i>
                                    <b> No. Pendaftaran </b> : <?= session()->get('no_registrasi') ?>
                                </li>
                                <li class="mt-3"><i class="dripicons-document text-info font-18 mt- mr-2"></i>
                                    <b> No. Virtual Account </b> : <?= session()->get('no_virtual') ?>
                                </li>
                                <li class="mt-3 md-0"><i class="dripicons-mail text-info font-18 mt-2 mr-2"></i>
                                    <b> Email </b> : <?= session()->get('email') ?>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="card-body">
                <ul class="nav nav-pills mb-0" id="pills-tab" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="general_detail_tab" data-toggle="pill"
                            href="#general_detail">Data Pendaftaran</a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-12">
        <div class="tab-content detail-list" id="pills-tabContent">
            <div class="tab-pane fade show active" id="general_detail">
                <div class="row">
                    <div class="col-lg-8">
                        <div class="card">
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table mb-0 table-centered">
                                        <tbody>
                                            <tr>
                                                <td><b>Tempat Tanggal Lahir</b></td>
                                                <td><?= session()->get('kota_lahir') ?>,
                                                    <?= date("d F Y", strtotime(session()->get('tanggal_lahir'))) ?>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td><b>Asal Sekolah</b></td>
                                                <td><?= session()->get('asal_sekolah') ?></td>
                                            </tr>
                                            <tr>
                                                <td><b>Nama Orangtua</b></td>
                                                <td><?= session()->get('nama_orangtua') ?></td>
                                            </tr>
                                            <tr>
                                                <td><b>No. Whatsapp</b></td>
                                                <td><?= session()->get('no_whatsapp') ?></td>
                                            </tr>
                                            <tr>
                                                <td><b>Bukti Pembayaran</b></td>
                                                <td>
                                                    <img src="<?= base_url() ?>/upload/bukti_pembayaran/<?= session()->get('slug_unit') ?>/<?= session()->get('bukti_pembayaran') ?>"
                                                        alt="<?= session()->get('nama_lengkap') ?>"
                                                        style="max-width: 300px;">
                                                </td>
                                            </tr>
                                            <?php if(session()->get('slug_unit') === 'smp' && session()->get('asal_sekolah') === 'SD Santa Ursula Bandung') : ?>
                                            <tr>
                                                <td><b>Surat Pengantar</b></td>
                                                <td>
                                                    <a href="<?= base_url() ?>/upload/surat_pengantar/<?= session()->get('slug_unit') ?>/<?= session()->get('surat_pengantar') ?>"
                                                        target="_black">
                                                        Buka Surat Pengantar
                                                    </a>
                                                </td>
                                            </tr>
                                            <?php endif ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>