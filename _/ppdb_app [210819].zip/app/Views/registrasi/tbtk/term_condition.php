<?= $this->extend('registrasi/layouts/template') ?>

<?= $this->section('content') ?>
<div class="row vh-100 ">
    <div class="col-12 align-self-center">
        <div class="auth-page">
            <div class="card auth-card shadow-lg">
                <div class="card-body">
                    <div class="px-3">
                        <div class="auth-logo-box">
                            <a href="#0">
                                <img src="<?= base_url() ?>/back/images/logo_serviam.png" height="80" alt="logo"
                                    class="auth-logo">
                                <img src="<?= base_url() ?>/back/images/logo_entrepreneur.png" height="80" alt="logo"
                                    class="auth-logo">
                            </a>
                        </div>
                        <div class="text-center auth-logo-text">
                            <h3 class="mt-0 mb-3 mt-5"><b>KETENTUAN PPDB ONLINE TB-TK SANTA URSULA</b></h3>
                        </div><br>

                        <div class="row">
                            <div class="col-md-12 col-lg-12">
                                <div class="card">
                                    <div class="card-body">
                                        <div class="row">
                                            <div class="col-md-12 col-lg-1">
                                                <h3 class="text-center">1</h3>
                                            </div>
                                            <div class="col-md-12 col-lg-11">
                                                <h4 class="text-justify">
                                                    Calon peserta didik terlebih dahulu melakukan pembayaran biaya
                                                    administrasi sebesar <b>Rp. 150.000,00</b> yang dapat ditrasfer
                                                    melalui rekening <b>Bank Mandiri : 13 100 7777 9900 a.n. Yayasan
                                                        Prasama Bhakti</b>. Bukti pembayaran dapat diupload saat
                                                    pengisian formulir pendaftaran.
                                                </h4>
                                            </div>
                                            <div class="col-md-12 col-lg-1">
                                                <h3 class="text-center">2</h3>
                                            </div>
                                            <div class="col-md-12 col-lg-11">
                                                <h4 class="text-justify">
                                                    Calon peserta didik diwajibkan untuk mengisi formulir pendaftaran
                                                    dengan lengkap dan sebenar-benarnya.
                                                </h4>
                                            </div>
                                            <div class="col-md-12 col-lg-1">
                                                <h3 class="text-center">3</h3>
                                            </div>
                                            <div class="col-md-12 col-lg-11">
                                                <h4 class="text-justify">
                                                    Calon peserta didik diwajibkan mengingat atau mencatat secara
                                                    pribadi <b>alamat email dan password</b> yang diisi dalam formulir
                                                    pendaftaran untuk keperluan login ke halaman dashboard calon peserta
                                                    didik.
                                                </h4>
                                            </div>
                                            <div class="col-md-12 col-lg-1">
                                                <h3 class="text-center">4</h3>
                                            </div>
                                            <div class="col-md-12 col-lg-11">
                                                <h4 class="text-justify">
                                                    Untuk kenyamanan lebih dalam mengisi formulir pendaftaran,
                                                    direkomendasikan menggunakan PC atau laptop.
                                                </h4>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <form action="/tbtk_registrasi/form" class="form-horizontal auth-form my-4"
                                    method="post" enctype="multipart/form-data">
                                    <div class="row">
                                        <div class="col-md-8">
                                            <div class="custom-control custom-switch switch-success">
                                                <input type="checkbox" class="custom-control-input"
                                                    id="customSwitchSuccess">
                                                <label class="custom-control-label" for="customSwitchSuccess">
                                                    <h4 style="margin: 0">
                                                        Saya sudah memahami dan menyetujui semua ketentuan yang berlaku.
                                                    </h4>
                                                </label>
                                            </div>
                                        </div>
                                        <div class="col-md-4">
                                            <div class="d-flex flex-row-reverse">
                                                <button class="btn btn-lg btn-success waves-effect waves-light"
                                                    type="submit" name="sendNewSms" id="sendNewSms"
                                                    disabled="disabled">Formulir Pendaftaran</button>
                                            </div>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?= $this->endSection() ?>