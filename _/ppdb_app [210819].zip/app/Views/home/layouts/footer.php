<footer>
    <div class="container margin_60_35">
        <div class="row">
            <div class="col-md-8">
                <ul id="additional_links">
                    <li><a href="https://santaursula-bdg.sch.id/" target="_blank">Yayasan Prasama Bhakti</a></li>
                </ul>
            </div>
            <div class="col-md-4">
                <div id="copy">© <?= date('Y') ?> ITPB</div>
            </div>
        </div>
    </div>
</footer>
<!--/footer-->